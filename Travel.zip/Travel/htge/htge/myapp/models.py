from unittest.util import _MAX_LENGTH
import uuid
from django.db import models
from datetime import datetime
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser
from django.db.models.fields import CharField, NullBooleanField
from pkg_resources import Requirement
import datetime


class MyUser(AbstractUser):
    ROLE_CHOICES=(
        ('Admin','Admin'),
        ('Client','Client'),
        
    )
   
    Contact=models.CharField(max_length=100,default='')
    Role=models.CharField(max_length=100,choices=ROLE_CHOICES,blank=True,null=True)
    
class Admin(models.Model):
    ref=models.OneToOneField(MyUser,on_delete=models.CASCADE)


class Package(models.Model):
    Name=models.CharField(max_length=100,default='')
    Location=models.CharField(max_length=100,default='')
    price=models.CharField(max_length=100,default='')
    members=models.CharField(max_length=100,default='')
    days=models.CharField(max_length=100,default='')
    created_date=models.DateTimeField(auto_now_add=True)
    image=models.FileField(upload_to="images/%y",default='')
    remark=models.CharField(max_length=100,default='')
    Description=models.CharField(max_length=200,default='')
    from_date=models.DateField(blank=True, null=True)
    to_date=models.DateField(blank=True, null=True)

class Booked(models.Model):
    Name=models.CharField(max_length=100,default='')
    Location=models.CharField(max_length=100,default='')
    price=models.CharField(max_length=100,default='')
    members=models.CharField(max_length=100,default='')
    days=models.CharField(max_length=100,default='')
    Package_createdon=models.CharField(max_length=100,default='')
    image=models.FileField(upload_to="images/%y")
    remark=models.CharField(max_length=100,default='')
    Description=models.CharField(max_length=200,default='')
    from_date=models.DateField(blank=True, null=True)
    to_date=models.DateField(blank=True, null=True)
    username=models.CharField(max_length=100,default='')
    created_date=models.DateTimeField(auto_now_add=True)
    email=models.CharField(max_length=100,default='')
    card_name=models.CharField(max_length=100,default='')
    card_no=models.CharField(max_length=100,default='')
    