from django import forms
from django.forms import widgets
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from ckeditor.fields import RichTextFormField
from django.contrib.auth.models import User
from django.forms import formset_factory
User = get_user_model()

class userForm(UserCreationForm):
    class Meta:
        model=MyUser
        fields = ['Contact','username', 'email', 'password1', 'password2','Role']

# class userForm(UserCreationForm):
#     class Meta:
#         model=MyUser
#         fields = ['Contact','first_name', 'last_name', 'username', 'email', 'password1', 'password2','Role']

class PackageForm(forms.ModelForm):
    class Meta:
        model=Package
        fields = ['Name','Location','price','members','days','image','Description','from_date','to_date']


class BookingForm(forms.ModelForm):
    class Meta:
        model=Booked
        # fields = ['Name','Location', 'price', 'members', 'days','image','Description','from_date','to_date'
        #           ,'username','email','card_name','card_no']
        fields = ['Name','Location','price','Description','members','days','username','email','card_name','card_no']